#%%

#将网页读入 BeautifulSoup并用html.parser剖析器防止警告的产生
import requests
from bs4 import BeautifulSoup
res=requests.get('http://news.sina.com.cn/china/')
res.encoding='utf-8'
soup=BeautifulSoup(res.text,'html.parser')

#%%

commenturl='http://comment5.news.sina.com.cn/page/info?version=1&\
format=json&channel=gn&newsid=comos-{}&group=undefined&\
compress=0&ie=utf-8&oe=utf-8&page=1&page_size=3&t_size=3&h_size=3'

#%%

#动态获取新闻的评论数
import re
import json
def getcomments(newsurl):
    m=re.search('doc-i(.*).shtml',newsurl)
    newsid=m.group(1)
    comments=requests.get(commenturl.format(newsid))
    jd = json.loads(comments.text.strip('var data='))
    return jd['result']['count']['total']

#%%

#新闻的信息抽取函数
def getNewsDetail(newsurl):
    result={}
    res=requests.get(newsurl)
    res.encoding='utf-8'
    soup=BeautifulSoup(res.text,'html.parser')
    result['tittle']=soup.select('.main-title')[0].text
    #result['newssource']=soup.select('.date-source a')[0].text
    timesource=soup.select('.date')[0].contents[0].strip()
    result['dt']=timesource
    #result['dt']=datetime.strptime(timesource,'%Y年%m月%d日%H:%M')
    result['article']=' '.join( [p.text.strip()  for p in soup.select('.article p')[:-1]])
    result['editor']=soup.select('.show_author')[0].text.lstrip('责任编辑：')
    result['comment']=getcomments(newsurl)
    return result

#%%

getNewsDetail('http://news.sina.com.cn/c/nd/2018-07-24/doc-ihftenhz6977167.shtml')

#%%

def parselistlinks(url):
    newsdetails=[]
    res=requests.get(url)
    jd=json.loads(res.text.lstrip("'  newsloadercallback(").rstrip(');'))
    for ent in jd['result']['data']:
        newsdetails.append(getNewsDetail(ent['url']))
    return newsdetails

#%%

url='http://api.roll.news.sina.com.cn/zt_list?channel=news&\
cat_1=gnxw&cat_2==gdxw1||=gatxw||=zs-pl||=mtjj&level==1||=2&\
show_ext=1&show_all=1&show_num=22&tag=1&format=json&page=2&\
callback=newsloadercallback&_=1532430031835'

#%%

parselistlinks(url)

#%%

url='http://api.roll.news.sina.com.cn/zt_list?channel=news&\
cat_1=gnxw&cat_2==gdxw1||=gatxw||=zs-pl||=mtjj&level==1||=2&\
show_ext=1&show_all=1&show_num=22&tag=1&format=json&page={}&\
callback=newsloadercallback&_=1532430031835'
news_total=[]
for i in range(1,2):
    newsurl=url.format(i)
    newsary=parselistlinks(newsurl)
    news_total.extend(newsary)

#%%

len(news_total)

#%%

news_total

#%%

import pymysql
db = pymysql.connect('localhost','root','951010','student',charset='utf8')
cur = db.cursor()
sqlc = '''
    create table news(
    id int(11) not null auto_increment primary key,
    article text not null,
    comment int(5) not null,
    dt varchar(20) not null,
    editor varchar(50) not null,
    tittle varchar(50) not null
    )
    '''
cur.execute(sqlc)#创建数据库

for new_total in news_total:
    article = new_total['article']
    comment = new_total['comment']
    dt = new_total['dt']
    editor = new_total['editor']
    tittle = new_total['tittle']
    sqli = '''insert into news(article,comment,dt,editor,tittle)
    values('%s','%d','%s','%s','%s')
    '''%(article,comment,dt,editor,tittle)
    try:
        cur.execute(sqli)#执行sql语句 ，插入数据
        db.commit()# 提交到数据库执行
        print('导入数据库成功')
    except:
        db.rollback()# 如果发生错误则回滚
        print('shibai')
    cursor.close()#关闭游标

#%%

import pandas
df = pandas.DataFrame(news_total)
#df.head(10)
df

#%%

df.to_excel('news.xlsx')

#%%


