import jieba
#加载自定义词库
jieba.load_userdict('all_words.txt')
#导入停止词
with open('mystopwords.txt', encoding='utf-8') as words:
    stop_words = [ i.strip() for i in words.readlines() ]
#切词时删除停止词
def cut_word(sentence):
    words = [ i for i in jieba.lcut(sentence) if i not in stop_words ]
    return ' '.join(words)
#保存切词结果
words = news['title'].apply(cut_word)
from sklearn.feature_extraction.text import CountVectorizer
#统计各个词的出现次数，过滤出现频率过低的词，min_df根据样本量适当调整。
counts = CountVectorizer(min_df = 0.0005)
#词条矩阵
counts_mat = counts.fit_transform(words).toarray()
#矩阵列名
columns = counts.get_feature_names()
#得到数据清洗完成后的样本
X = pd.DataFrame(counts_mat, columns=columns)
y = news['category']

#使用TF-IDF构造词条矩阵
from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer(sublinear_tf=True, max_df=0.2, min_df=0.0005)
tfidf_mat = vectorizer.fit_transform(words).toarray()
columns = vectorizer.get_feature_names()
X_1 = pd.DataFrame(tfidf_mat, columns=columns)
y_1 = news['category']

from sklearn import model_selection, metrics, naive_bayes
#把数据拆分为训练集和测试集
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.25)
#构造多项式贝叶斯分类器
mnb = naive_bayes.MultinomialNB()
#拟合训练集
mnb.fit(X_train, y_train)
#预测测试集
mnb_pred = mnb.predict(X_test)
#混淆矩阵
cm = pd.crosstab(mnb_pred, y_test)
#查看准确率
metrics.accuracy_score(y_test, mnb_pred)

