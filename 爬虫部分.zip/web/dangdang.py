# -*- coding:utf-8 -*-
# author:Air
# software: PyCharm
# 学习交流qq群：916696436

import requests
from bs4 import BeautifulSoup
import re
import pymysql

# # 打开数据库连接
# db = pymysql.connect("localhost", "root", "123456", "testdb")
#
# # 使用cursor()方法获取操作游标
# cursor = db.cursor()
#
# # SQL 插入语句
# sql = "INSERT INTO EMPLOYEE(FIRST_NAME, \
#        LAST_NAME, AGE, SEX, INCOME) \
#        VALUES ('%s', '%s',  %s,  '%s',  %s)" % \
#       ('Mac', 'Mohan', 20, 'M', 2000)
# try:
#     # 执行sql语句
#     cursor.execute(sql)
#     # 执行sql语句
#     db.commit()
# except:
#     # 发生错误时回滚
#     db.rollback()
#
# # 关闭数据库连接
# db.close()


def insert(value):
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "123456", "testdb")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()

    # SQL 插入语句
    sql = "INSERT INTO EMPLOYER(LOGO,PRICE,AUTHER) VALUES (%s, %s, %s)"
    try:
        # 执行sql语句
        cursor.execute(sql, value)
        db.commit()
        print('插入数据成功')
    except:
        # 发生错误时回滚
        db.rollback()
        print("插入数据失败")
    db.close()

if __name__ == '__main__':


    # re匹配需要的数据
    pertern = re.compile(
        r'<img.*?data-original="(.*?)".*?<span class="search_now_price">(.*?)</span>.*?<a.*?单品作者.*?title="(.*?)">.*?</a>',
        re.S)
    # 添加请求头   修改user-agent来伪装浏览器
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36'}
    url = 'http://category.dangdang.com/cp01.19.34.00.00.00.html'
    res = requests.get(url, headers=headers)
    print(res.status_code)
    soup = BeautifulSoup(res.text, 'html.parser')
    data = soup.find_all('ul', attrs={'class': 'bigimg'})
    data = str(data)
    item = re.findall(pertern, data)
    for i in item:
        print(i)
        insert(i)